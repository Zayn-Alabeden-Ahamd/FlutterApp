// استيراد مكتبة مصادقة فايربيز
import 'package:flutter/material.dart'; // استيراد مكتبة فلاتر لتصميم واجهات Android


import 'costmertextfiled.dart'; // استيراد حقل النص المخصص

// تعريف واجهة التسجيل
class regiser extends StatefulWidget {
  const regiser({super.key});

  @override
  State<regiser> createState() => _regiserState(); // إنشاء حالة واجهة التسجيل
}

// تعريف حالة واجهة التسجيل
class _regiserState extends State<regiser> {
 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Form(
        
        child: Stack(
          children: [
            // خلفية الشاشة
            Container(
                height: 1000,
                width: 500,
                decoration: BoxDecoration(
                  color: Colors.purple[600],
                )),
            // حاوية محتوى النموذج
            Container(
              height: 1000,
              margin: const EdgeInsets.symmetric(vertical: 15, horizontal: 7),
              padding: const EdgeInsets.only(top: 80),
              width: 500,
              decoration: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(90)),
              child: ListView(
                children: [
                  // عنوان النموذج
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 20),
                    child: Column(
                      children: [
                        Text(
                          "Sign up",
                          style: TextStyle(
                              color: Colors.purple,
                              fontSize: 30,
                              fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                  // حقول الإدخال
                  Container(
                      child: Column(
                    children: [
                      // حقل إدخال البريد الإلكتروني
                      costmer(
                        iconn: Icons.email,
                        namee: "Enter your Email",
                        title: "Email",
                       
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      // حقل إدخال كلمة المرور
                      costmer(
                        iconn: Icons.password,
                        namee: "Enter your password",
                        title: "Password",
                       
                      ),
                    ],
                  )),
                  const SizedBox(
                    height: 30,
                  ),
                  // زر التسجيل
                  Container(
                    margin: const EdgeInsets.symmetric(vertical: 20),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(60),
                      color: Colors.purple,
                    ),
                    child: MaterialButton(
                      onPressed: ()  {
                       
                      },
                      child: Text(
                        "Sign up",
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 25),
                      ),
                    ),
                  ),
                  // زر تسجيل الدخول باستخدام جوجل
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Container(
                        height: 50,
                        margin: EdgeInsets.symmetric(vertical: 10),
                        width: 250,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(60),
                          color: Colors.red,
                        ),
                        child: InkWell(
                            onTap: () {
                              
                            },
                            child: Container(
                              height: 35,
                              width: 35,
                              alignment: Alignment.center,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(60),
                                child: Image.asset(
                                  "images/go.jpg",
                                  fit: BoxFit.cover,
                                ),
                              ),
                            )),
                      ),
                    ],
                  ),
                  // رابط تسجيل الدخول للمستخدمين الحاليين
                  Container(
                    margin: EdgeInsets.symmetric(vertical: 10, horizontal: 60),
                    child: Row(
                      children: [
                        Text(
                          "Have Account?",
                          style: TextStyle(
                              fontSize: 15, fontWeight: FontWeight.bold),
                        ),
                        InkWell(
                          onTap: () {
                            Navigator.of(context).pushReplacementNamed("login");
                          },
                          child: Container(
                            width: 80,
                            alignment: Alignment.center,
                            height: 20,
                            decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(60)),
                            child: Text(
                              "Login now",
                              style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.purple[600]),
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                ],
              ),
            ),
            // صورة إضافية في أعلى الشاشة
            Container(
                height: 140,
                margin: EdgeInsets.symmetric(horizontal: 110),
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                      bottomRight: Radius.circular(60),
                      bottomLeft: Radius.circular(60)),
                  color: Colors.purple[600],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(60),
                  child: Image.asset(
                    "images/welcom.jpg",
                    fit: BoxFit.cover,
                  ),
                )),
          ],
        ),
      ),
    );
  }
}
