
import 'package:flutter/material.dart'; // استيراد مكتبة فلاتر لتصميم واجهات Android

import 'costmertextfiled.dart'; // استيراد حقل النص المخصص

// تعريف واجهة تسجيل الدخول
class login extends StatefulWidget {
  const login({super.key});

  @override
  State<login> createState() => _loginState(); // إنشاء حالة واجهة تسجيل الدخول
}

// تعريف حالة واجهة تسجيل الدخول
class _loginState extends State<login> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Form(
      
        child: Stack(
          children: [
            // خلفية الشاشة
            Container(
                height: 1000,
                width: 500,
                decoration: BoxDecoration(
                  color: Colors.purple[600],
                )),
            // حاوية محتوى النموذج
            Container(
              height: 1000,
              margin: EdgeInsets.symmetric(vertical: 15, horizontal: 7),
              width: 500,
              decoration: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(90)),
              child: ListView(children: [
                      // محتوى النموذج
                      Column(
                        children: [
                          // صورة الترحيب
                          Container(
                              height: 80,
                              width: 80,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(60),
                                color: Colors.amber,
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(60),
                                child: Image.asset(
                                  "images/welcom.jpg",
                                  fit: BoxFit.cover,
                                ),
                              ))
                        ],
                      ),
                      // عنوان النموذج
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        child: Column(
                          children: [
                            Padding(
                              padding: const EdgeInsets.symmetric(vertical: 10),
                              child: const Text(
                                "Login",
                                style: TextStyle(
                                    color: Colors.purple,
                                    fontSize: 30,
                                    fontWeight: FontWeight.bold),
                              ),
                            ),
                            Text(
                              "Enter your personal information ",
                              style: TextStyle(
                                  color: Colors.grey[600], fontSize: 20),
                            )
                          ],
                        ),
                      ),
                      // حقل إدخال البريد الإلكتروني
                      costmer(
                        iconn: Icons.email,
                        namee: "Enter your Email",
                        title: "Email",
                      
                       
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      // حقل إدخال كلمة المرور
                      costmer(
                        iconn: Icons.password,
                        namee: "Enter your password",
                        title: "Password",
                        
                      ),
                      // رابط نسيان كلمة المرور
                      Container(
                        margin: EdgeInsets.only(left: 195, right: 20, top: 5),
                        padding: EdgeInsets.symmetric(horizontal: 5),
                        decoration: BoxDecoration(
                            color: Colors.purple[600],
                            borderRadius: BorderRadius.circular(60)),
                        child: InkWell(
                          
                          child: Text(
                            "Forget Password ?",
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                      // رابط التسجيل
                      Column(
                        children: [
                          Container(
                            margin: const EdgeInsets.only(top: 40),
                            child: Row(
                              children: [
                                Text(
                                  "Dont Have An Account",
                                  style: TextStyle(fontSize: 15),
                                ),
                                InkWell(
                                 
                                  child: Text(
                                    "Sign in Now",
                                    style: TextStyle(
                                        color: Colors.purple,
                                        fontSize: 15,
                                        fontWeight: FontWeight.bold),
                                  ),
                                )
                              ],
                            ),
                          ),
                        ],
                      ),
                      // زر تسجيل الدخول
                      Container(
                        margin:
                            EdgeInsets.symmetric(vertical: 20, horizontal: 10),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(60),
                          color: Colors.purple[600],
                        ),
                        child: MaterialButton(
                          onPressed: ()  {
                            
                                },
                          child: Text(
                            "Login",
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 25),
                          ),
                        ),
                      ),
                    ]),
            ),
            // صورة إضافية في أعلى الشاشة
            Container(
                height: 140,
                margin: EdgeInsets.symmetric(horizontal: 110),
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                      bottomRight: Radius.circular(60),
                      bottomLeft: Radius.circular(60)),
                  color: Colors.purple[600],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(60),
                  child: Image.asset(
                    "images/welcom.jpg",
                    fit: BoxFit.cover,
                  ),
                )),
          ],
        ),
      ),
    );
  }
}
